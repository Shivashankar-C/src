import React from 'react';
import VoiceAssistant from './VoiceAssistant';
import './App.css'; // Import a CSS file for styles

const App = () => {
  return (
    <div className="app-container">
      <nav className="navbar">
        <ul>
          <li><a href="https://leotechwave.com/">Leo Tech Wave</a></li>
          <li><a href="#search">Search</a></li>
          <li><a href="#help">Help</a></li>
        </ul>
      </nav>
      <VoiceAssistant />
      <div className="emoji-container">
        <span role="img" aria-label="sparkles">✨</span>
        <span role="img" aria-label="microphone">🎤</span>
        <span role="img" aria-label="sparkles">✨</span>
      </div>
    </div>
  );
};

export default App;
