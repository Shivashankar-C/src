// src/VoiceAssistant.js

import React, { useState } from 'react';
import axios from 'axios';

const jokes = [
  "Why did the clock get kicked out of the class? Because it kept talking back!",
  "What did one wall say to the other wall? I'll meet you at the corner!",
  "Why did the calendar get dumped? It had too many dates!"
];

const VoiceAssistant = () => {
  const [response, setResponse] = useState('');

  const startListening = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognition();

    recognition.onstart = () => {
      console.log("Voice recognition activated. Try speaking into the microphone.");
    };

    recognition.onresult = (event) => {
      const spokenText = event.results[0][0].transcript;
      console.log(`You said: ${spokenText}`);
      handleCommand(spokenText);
    };

    recognition.onerror = (event) => {
      console.error("Error occurred in recognition: " + event.error);
    };

    recognition.start();
  };

  const handleCommand = async (command) => {
    if (command.includes('joke')) {
      const joke = jokes[Math.floor(Math.random() * jokes.length)];
      setResponse(joke);
    } else {
      const query = command.replace('search', '').trim();
      if (query) {
        const wikiUrl = `https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${query}&format=json&origin=*`;
        try {
          const result = await axios.get(wikiUrl);
          const page = result.data.query.search[0];
          const pageTitle = page?.title || "No results found";
          const pageSnippet = page?.snippet.replace(/<[^>]+>/g, '') || "No details available"; // Remove HTML tags
          const currentDateTime = new Date().toLocaleString();
          setResponse(`Here's the information: ${pageTitle} - ${pageSnippet}. Current date and time: ${currentDateTime}`);
        } catch (error) {
          setResponse("Sorry, I couldn't fetch data from Wikipedia.");
        }
      } else {
        setResponse("Please tell me what to search for.");
      }
    }
  };

  return (
    <div style={{ textAlign: 'center', padding: '20px' }}>
      <h1>Voice Assistant</h1>
      <button onClick={startListening}>Start Listening</button>
      <p>{response}</p>
    </div>
  );
};

export default VoiceAssistant;
